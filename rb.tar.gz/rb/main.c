#include <stdio.h>
#include <stdlib.h>
#include "rb.h"

int main(int argc, char * argv[]) {
	arvore a;
	int opcao;
	int cont = 0;
	int cont_remo = 0;
	inicializar(&a);

	while(1) {
		printf("\t\t\n\n-------------- MENU --------------\n\n");
		scanf("%d", &opcao);

		switch(opcao){
				int valor;
				/*case 1:
						printf("%d\n", altura(a));
						break;
				*/
				case 1:
					printf("\t\t\n\n-------------- ADICIONAR --------------\n\n");
					scanf("%d", &valor);
					adicionar(valor, &a);
					cont++;
					printf("contagem: [%d]", cont);
					//in_order(a);
					//imprimir(a);
					break;
				case 5:
					pre_order(a);
					printf("\n");
					break; 
				case 6:
					in_order(a);
					printf("\n");
					break;
				case 7:
					pos_order(a);
					printf("\n");
					break;
				case 2:	
					printf("\t\t\n\n-------------- REMOVER --------------\n\n");
					scanf("%d", &valor);
					printf("depois insert\n");
					remover(valor, &a);
					printf("depois funcao\n");
					cont_remo++;
					printf("removido: [%d]", cont_remo);
					break;
				case 3:
					printf("maior elemento: [%d]\n", maior_elemento(a));
					break;
				case 4:
					printf("menor elemento: [%d]\n", menor_elemento(a));
					break;
				case 10:
					//imprimir(a);

					in_order(a);
					//pre_order(a);
					printf("\n\t\t\n ----------- Altura -----------\n\n");
					printf("\n\n\n[%d]", altura(a));
				
					printf("\n");
					break;

				case 99:
						exit(0);
		}
	}
}